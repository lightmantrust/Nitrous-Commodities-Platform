import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

function App() {
  return <div className='p-6 text-white bg-black'>Nitrous Dashboard Initialized</div>;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
